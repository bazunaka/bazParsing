create view pg_locks
            (locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
             virtualtransaction, pid, mode, granted, fastpath, waitstart)
as
SELECT l.locktype,
       l.database,
       l.relation,
       l.page,
       l.tuple,
       l.virtualxid,
       l.transactionid,
       l.classid,
       l.objid,
       l.objsubid,
       l.virtualtransaction,
       l.pid,
       l.mode,
       l.granted,
       l.fastpath,
       l.waitstart
FROM pg_lock_status() l(locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
                        virtualtransaction, pid, mode, granted, fastpath, waitstart);

alter table pg_locks
    owner to postgres;

grant select on pg_locks to public;

