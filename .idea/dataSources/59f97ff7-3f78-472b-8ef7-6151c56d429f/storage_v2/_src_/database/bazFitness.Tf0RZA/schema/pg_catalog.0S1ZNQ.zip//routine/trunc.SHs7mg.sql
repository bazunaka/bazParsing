create function trunc(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function trunc(numeric) owner to postgres;

